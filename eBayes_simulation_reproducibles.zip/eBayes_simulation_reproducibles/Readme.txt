Matlab file "Generate_all_Plots.m" generates all the plots in the manuscript. To generate the plots, open this file and execute the run command on MATLAB.

Folder "generate_plot_files" contains all the function files "generate_fig_xy.m", where function "generate_fig_xy" generates "fig_xy". E.g., generate_fig_1a is called to generate fig 1a in the manuscript. The main file "Generate_all_Plots.m" calls these functions to generate the plots.

Folder "Accessory_function_files" contains all the accessory function files used to generate the simulation plots.
