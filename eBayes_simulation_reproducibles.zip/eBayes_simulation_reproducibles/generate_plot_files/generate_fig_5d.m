function generate_fig_5d

N = 10000;
delta = 0.5;  % sampling factor

n = ceil(delta * N);
epsilon = 0.05;  % sparsity factor

load alpha_map.mat alpha;
load alpha_map.mat f_alpha;
t_alpha = min(alpha(f_alpha < epsilon)); %sparsity to lambda conversion

sigma = 0.05;  % sigma^2 = Noise variance

eps = 0.02 : 0.02 : 1;

%%%%%%%%%%%%%%% measurement matrix %%%%%%%%%%%%%%%%%%

A = (1/sqrt(n)) * randn(n,N); % Gaussian

%%%%%%%%% Generate theta %%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%% The non-zero entries of theta take value
%%%%% 1  with probability epsilon/2, -1 with probability epsilon/2, 0
%%%%% otherwise %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
num = ceil(N*epsilon*0.5);
theta = [ones(num,1) ; -1*ones(num,1)  ; zeros(N-2*num,1)];
theta = theta(randperm(N));
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

iter = 25; % number of iterations
tau = zeros(1,iter);
tau_actual = zeros(1,iter);

tau1 = zeros(1,iter);
tau_actual1 = zeros(1,iter);

tau2 = zeros(1,iter);
tau_actual2 = zeros(1,iter);

opt_eps = zeros(1,iter);

y = A*theta + sigma*randn(n,1);

theta_est = zeros(N,iter);
z = zeros(n,iter);
z(:,1) = y;

tau(1) = y'*y/n;
tau_actual(1) = (1/N)*(theta'*theta);

%%%% Soft Threshhold %%%%%%%%%%%%%%

theta_est1 = zeros(N,iter);
z1 = zeros(n,iter);
z1(:,1) = y;

tau1(1) = y'*y/n;
tau_actual1(1) = (1/N)*(theta'*theta);

%%%% Hybrid %%%%%%%%%%%%%%

theta_est2 = zeros(N,iter);
z2 = zeros(n,iter);
z2(:,1) = y;

tau2(1) = y'*y/n;
tau_actual2(1) = (1/N)*(theta'*theta);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

for ind = 2 : iter
    temp = A'*z(:,ind-1) + theta_est(:,ind-1);
    
    %%%% find best epsilon %%%%%%%%%%%%%%%%%%%%
    z_range = zeros(1,length(eps));
    for eps_ind = 1 : length(eps)
        theta_temp = eBayes_estimator(temp, sqrt(tau(ind-1)),eps(eps_ind));
        v = eBayes_derivative(temp,sqrt(tau(ind-1)),eps(eps_ind));
        z_temp = y - A*theta_temp + (1/delta)*z(:,ind-1)*mean(v);
        z_range(eps_ind) = z_temp'*z_temp/n;
    end
    [~, idx] = min(z_range);
    opt_epsilon = eps(idx);
    opt_eps(ind) = opt_epsilon;   
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    theta_est(:,ind) = eBayes_estimator(temp, sqrt(tau(ind-1)),opt_epsilon);    
    v = eBayes_derivative(temp,sqrt(tau(ind-1)),opt_epsilon);
    z(:,ind) = y - A*theta_est(:,ind) + (1/delta)*z(:,ind-1)*mean(v);
    tau(ind) = z(:,ind)'*z(:,ind)/n;
    tau_actual(ind) = (1/N)*(theta_est(:,ind)-theta)'*(theta_est(:,ind)-theta);
    
    %%%%%%%%%%% soft threshhold %%%%%%%%%%%%%%%%%%%%%%%%%%%%%   
    
    temp1 = A'*z1(:,ind-1) + theta_est1(:,ind-1);
    theta_est1(:,ind) = soft_thresh(temp1, sqrt(tau1(ind-1)),t_alpha);
    v1 = soft_thresh_derivative(temp1,sqrt(tau1(ind-1)),t_alpha);    
    z1(:,ind) = y - A*theta_est1(:,ind) + (1/delta)*z1(:,ind-1)*mean(v1);    
    tau1(ind) = z1(:,ind)'*z1(:,ind)/n;
    tau_actual1(ind) = (1/N)*(theta_est1(:,ind)-theta)'*(theta_est1(:,ind)-theta);    
end

%%%%%%%%%%%%%%% Hybrid %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
count = 0;
for ind = 2 : iter
    temp2 = A'*z2(:,ind-1) + theta_est2(:,ind-1);    
    z_range = zeros(1,length(eps));
    for eps_ind = 1 : length(eps)
        theta_temp = eBayes_estimator(temp2, sqrt(tau2(ind-1)),eps(eps_ind));
        v = eBayes_derivative(temp2,sqrt(tau2(ind-1)),eps(eps_ind));
        z_temp = y - A*theta_temp + (1/delta)*z2(:,ind-1)*mean(v);
        z_range(eps_ind) = z_temp'*z_temp/n;
    end
    [z_t1, idx] = min(z_range);
    opt_epsilon = eps(idx);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    alpha = 0 : 0.1 : sqrt(2*log(N)*tau2(ind-1));
    z_range = zeros(1,length(alpha));
    for alpha_ind = 1 : length(alpha)
        theta_temp = soft_thresh(temp2, sqrt(tau2(ind-1)), alpha(alpha_ind));
        v = soft_thresh_derivative(temp2,sqrt(tau2(ind-1)),alpha(alpha_ind));        
        z_temp = y - A*theta_temp + (1/delta)*z2(:,ind-1)*mean(v);        
        z_range(alpha_ind) = z_temp'*z_temp/n;
    end
    
    [z_t2, idx] = min(z_range);
    t_alpha = alpha(idx);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    if(z_t1 < z_t2)
        theta_est2(:,ind) = eBayes_estimator(temp2, sqrt(tau2(ind-1)),opt_epsilon);
        v = eBayes_derivative(temp2,sqrt(tau2(ind-1)),opt_epsilon);
        z2(:,ind) = y - A*theta_est2(:,ind) + (1/delta)*z2(:,ind-1)*mean(v);
        count = count + 1;
    else
        theta_est2(:,ind) = soft_thresh(temp2, sqrt(tau2(ind-1)),t_alpha);
        v = soft_thresh_derivative(temp2,sqrt(tau2(ind-1)),t_alpha);        
        z2(:,ind) = y - A*theta_est2(:,ind) + (1/delta)*z2(:,ind-1)*mean(v);        
    end
    tau2(ind) = z2(:,ind)'*z2(:,ind)/n;
    tau_actual2(ind) = (1/N)*(theta_est2(:,ind)-theta)'*(theta_est2(:,ind)-theta);      
end

tau_actual(iter) = (1/N)*(theta_est(:,iter)-theta)'*(theta_est(:,iter)-theta);

iteration_ind = 0 : iter-1;

SE_Pred = max(delta*(tau2 - sigma^2),0);

figure

semilogy(iteration_ind, tau_actual, 'b-','LineWidth',3)
hold on
semilogy(iteration_ind, tau_actual1, 'r--','LineWidth',3)
semilogy(iteration_ind, tau_actual2, 'k-*','LineWidth',3,'Markersize',10)
semilogy(iteration_ind, SE_Pred, 'm-o','LineWidth',3,'Markersize',10)

legend('MSE - eBayes Estimator','MSE - Soft-Thresholding','MSE - Hybrid Estimator', 'SE - Hybrid Estimator')
set(gca,'FontSize',24,'FontWeight', 'bold')
xlabel('Iteration','FontSize',32,'FontWeight', 'bold')
ylabel('MSE','FontSize',32,'FontWeight', 'bold')
title('fig 5d')
grid on