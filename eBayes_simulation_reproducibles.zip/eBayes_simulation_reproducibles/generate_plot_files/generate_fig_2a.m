function generate_fig_2a

n = 1000;

epsilon =  0.02 : 0.02 : 1; %sparsity parameter
sigma = 1; %noise variance
load('alpha_map.mat','alpha','f_alpha');

Soft_th_avg_distortion = zeros(1,length(epsilon));
eBayes_avg_distortion = zeros(1,length(epsilon));
hybrid_avg_distortion = zeros(1,length(epsilon));

for ind = 1 : length(epsilon)    
    t_alpha = min(alpha(f_alpha < epsilon(ind)));
    lambda = t_alpha*sigma; % soft-threshhold
    theta_mask =  binornd(1,epsilon(ind),n,1); %binary mask for sparsity
    theta = (theta_mask > 0).* [3*ones(n/2,1); -3*ones(n/2,1)];
      
    Soft_th_avg_distortion(ind) = soft_th_simulation(theta,sigma,lambda);
    eBayes_avg_distortion(ind) = eBayes_simulation(theta,sigma,epsilon(ind));
    hybrid_avg_distortion(ind) = hybrid_simulation(theta,sigma,epsilon(ind),t_alpha);
end

figure
plot(epsilon,Soft_th_avg_distortion, 'r--','LineWidth',4)
hold on
plot(epsilon,eBayes_avg_distortion, 'b-','LineWidth',4)
hold on
plot(epsilon,hybrid_avg_distortion, 'k-o','LineWidth',4,'MarkerSize',7)
hold on

set(gca,'FontSize',20,'FontWeight', 'bold')
xlabel('$$\eta $$','Interpreter','latex','FontSize',32,'FontWeight', 'bold')
str = '$$\tilde{R}(\theta,\hat{\theta})/n $$';
ylabel(str,'Interpreter','latex','FontSize',28,'FontWeight', 'bold')
ylim([0 1.4])
legend('Soft-Threshholding', 'eBayes', 'Hybrid')
title('fig 2a')
grid on