function generate_fig_4a

n = 50;

epsilon =  0.02 : 0.02 : 1; %sparsity parameter
sigma = 1; %noise variance
load('alpha_map.mat','alpha','f_alpha');

Soft_th_avg_distortion = zeros(1,length(epsilon));
eBayes_avg_distortion = zeros(1,length(epsilon));
hybrid_avg_distortion = zeros(1,length(epsilon));

for ind = 1 : length(epsilon)      
    theta_mask =  binornd(1,epsilon(ind),n,1); %binary mask for sparsity
    theta = (theta_mask > 0).* (2 * binornd(1,0.5,n,1) - 1);
      
    Soft_th_avg_distortion(ind) = soft_th_SureShrink(theta,sigma);
    eBayes_avg_distortion(ind) = eBayes_SureShrink(theta,sigma);
    hybrid_avg_distortion(ind) = hybrid_SureShrink(theta,sigma);
end

figure
plot(epsilon,Soft_th_avg_distortion, 'r--','LineWidth',4)
hold on
plot(epsilon,eBayes_avg_distortion, 'b-','LineWidth',4)
hold on
plot(epsilon,hybrid_avg_distortion, 'k-o','LineWidth',4,'MarkerSize',7)
hold on

set(gca,'FontSize',20,'FontWeight', 'bold')
xlabel('$$\eta $$','Interpreter','latex','FontSize',32,'FontWeight', 'bold')
str = '$$\tilde{R}(\theta,\hat{\theta})/n $$';
ylabel(str,'Interpreter','latex','FontSize',28,'FontWeight', 'bold')
legend('Soft-Threshholding', 'eBayes', 'Hybrid')
title('fig 4a')
grid on