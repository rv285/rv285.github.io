%%%% script to generate all plots

addpath(genpath(pwd))

fprintf('Plotting fig_1a... \n');
generate_fig_1a

fprintf('Done... \n');
fprintf('Plotting fig_1b...\n');
generate_fig_1b

fprintf('Done... \n');
fprintf('Plotting fig_2a...\n');
generate_fig_2a

fprintf('Done... \n');
fprintf('Plotting fig_2b...\n');
generate_fig_2b

fprintf('Done... \n');
fprintf('Plotting fig_3a...\n');
generate_fig_3a

fprintf('Done... \n');
fprintf('Plotting fig_3b...\n');
generate_fig_3b

fprintf('Done... \n');
fprintf('Plotting fig_3c...\n');
generate_fig_3c

fprintf('Done... \n');
fprintf('Plotting fig_3d...\n');
generate_fig_3d

fprintf('Done... \n');
fprintf('Plotting fig_4a...\n');
generate_fig_4a

fprintf('Done... \n');
fprintf('Plotting fig_4b...\n');
generate_fig_4b

fprintf('Done... \n');
fprintf('Plotting fig_4c...\n');
generate_fig_4c

fprintf('Done... \n');
fprintf('Plotting fig_4d...\n');
generate_fig_4d

fprintf('Done... \n');
fprintf('Plotting fig_5a...\n');
generate_fig_5a

fprintf('Done... \n');
fprintf('Plotting fig_5b...\n');
generate_fig_5b

fprintf('Done... \n');
fprintf('Plotting fig_5c...\n');
generate_fig_5c

fprintf('Done... \n');
fprintf('Plotting fig_5d...\n');
generate_fig_5d