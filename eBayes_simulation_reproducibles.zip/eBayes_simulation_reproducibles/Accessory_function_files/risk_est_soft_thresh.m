function x = risk_est_soft_thresh(y,sigma,t_alpha)

lambda = t_alpha*sigma; % threshhold

n = length(y);

t_1 = (y'*y)/n;
t_2 = y.^2.* (y >= lambda | y <= -lambda);
t_3 = (y >= lambda | y <= -lambda);


x = t_1 - mean(t_2) + (2+t_alpha^2)*sigma^2*mean(t_3) - sigma^2;