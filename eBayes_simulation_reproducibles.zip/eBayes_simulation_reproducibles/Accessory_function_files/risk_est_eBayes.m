function x = risk_est_eBayes(y,sigma,epsilon)

n = length(y);

y_bar = mean(y)/epsilon;

t = (1/epsilon)*max(0,y'*y/n - sigma^2 - epsilon*y_bar^2);

a1 = (y_bar + (1 - (sigma^2/(t + sigma^2)))*(y - y_bar));
b = 1 + ((1-epsilon)/epsilon) * sqrt(1 + t/sigma^2)...
    .*exp(-0.5*(y.^2 - (y-y_bar).^2/(1 + t)));

d = (1 - sigma^2/(t + sigma^2));

t_1 = norm(y - a1./b,2)^2/n;
t_2 = sum(d./b + a1.*(y - (y-y_bar)/(1 +t)).*(1./b - 1./b.^2))/n;

x = max(0, -1 + t_1 + 2*sigma^2*t_2);