function x = soft_thresh(y,D,alpha) %D is a vector containing sqrt of variances

Lambda = alpha*D; % threshhold
    
x = sign(y).*max(abs(y) - Lambda,0);
 