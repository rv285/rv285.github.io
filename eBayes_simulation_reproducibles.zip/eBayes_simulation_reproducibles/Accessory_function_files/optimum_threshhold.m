function x = optimum_threshhold(y, sigma)

n = length(y);

alpha = 0 : 0.1 : sqrt(2*log(n));

alpha_th_est = zeros(1,length(alpha));

t_1 = (y'*y)/n;

for ind = 1 : length(alpha)
    lambda = alpha(ind)*sigma;        
    t_2 = y.^2.* (y >= lambda | y <= -lambda);
    t_3 = (y >= lambda | y <= -lambda); 
    alpha_th_est(ind) = t_1 - mean(t_2) + (2+alpha(ind)^2)*sigma^2*mean(t_3) - sigma^2;
end

[~, idx] = min(alpha_th_est);
x = alpha(idx) * sigma;

