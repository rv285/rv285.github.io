function mse = eBayes_SureShrink(theta,sigma)
n = length(theta);
sum_mse = 0;

num_trials = 1000;
count = 1;
while (count < num_trials)
    y = theta + sigma*randn(n,1);
    epsilon = optimum_epsilon(y, sigma);    
    theta_est = eBayes_estimator(y,sigma,epsilon);
    error = theta-theta_est;
    sum_mse = sum_mse + error'*error; 
    count = count + 1;
end

mse = sum_mse/(n*num_trials);