function mse = hybrid_simulation(theta,sigma, epsilon,t_alpha)
n = length(theta);
sum_mse = 0;

num_trials = 1000;
count = 1;
while (count < num_trials)
    y = theta + sigma*randn(n,1);
    r1 = risk_est_eBayes(y,sigma,epsilon);
    r2 = risk_est_soft_thresh(y,sigma,t_alpha);
    if(r1 < r2) 
        theta_est = eBayes_estimator(y,sigma,epsilon);
    else
        lambda = t_alpha * sigma;
        theta_est = sign(y).*max(abs(y) - lambda,0);
    end
    error = theta-theta_est;
    sum_mse = sum_mse + error'*error;   
    count = count + 1;
end
mse = sum_mse/(n*num_trials);