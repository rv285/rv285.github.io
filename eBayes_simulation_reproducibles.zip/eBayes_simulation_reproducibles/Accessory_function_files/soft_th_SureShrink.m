function mse = soft_th_SureShrink(theta,sigma) 

n = length(theta);
sum_mse = 0;

num_trials = 1000;
count = 1;
while (count < num_trials)
    y = theta + sigma*randn(n,1);
    lambda = optimum_threshhold(y, sigma);
    theta_est = sign(y).*max(abs(y) - lambda,0);
    error = theta - theta_est;
    sum_mse = sum_mse + error'*error;  
    count = count + 1;
end
mse = sum_mse/(n*num_trials);