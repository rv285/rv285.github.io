function f_y = eBayes_estimator(y,sigma,epsilon) 
n = length(y);
if (sigma == 0)
    f_y = y;
else
    y = y/sigma;
    y_bar = mean(y)/epsilon;
    t = max(0,y'*y/n - epsilon*(y_bar)^2 - 1);
    t = t/epsilon;
    a = (y_bar + (1 - (1/(t + 1)))*(y - y_bar));
    b = 1 + ((1-epsilon)/epsilon) * sqrt(1 + t)...
        .*exp(-0.5*(y.^2 - (y-y_bar).^2/(1 + t)));
    f_y = sigma*(a./b);
end
