function opt_epsilon = optimum_epsilon(y, sigma)

eps = 0.02 : 0.02 : 1;
eps_est = zeros(1,length(eps));

for ind = 1 : length(eps)
    eps_est(ind) = risk_est_eBayes(y,sigma,eps(ind));
end

[~, idx] = min(eps_est);
opt_epsilon = eps(idx);