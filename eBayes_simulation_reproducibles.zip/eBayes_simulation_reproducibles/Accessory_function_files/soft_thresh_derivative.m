function x = soft_thresh_derivative(y,D,alpha) % D is a vector of sqrt of variances

Lambda = alpha*D; % threshhold
    
x = (y > Lambda) | (y < -Lambda);