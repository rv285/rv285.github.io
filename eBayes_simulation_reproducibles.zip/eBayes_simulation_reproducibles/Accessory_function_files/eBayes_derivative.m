function x = eBayes_derivative(y,sigma,epsilon)

n = length(y);

if (sigma == 0)
    x = ones(size(y));
else
    y = y/sigma;
    
    y_bar = mean(y)/epsilon;
    y_bar = 0;
    t = (1/epsilon)*max(0,y'*y/n - 1 - epsilon*y_bar^2);
    
    a1 = sigma*(y_bar + (1 - (1/(t + 1)))*(y - y_bar));
    b = 1 + ((1-epsilon)/epsilon) * sqrt(1 + t)...
        .*exp(-0.5*(y.^2 - (y-y_bar).^2/(1 + t)));
    
    d = (1 - 1/(t + 1));
    x = (d./b + (a1/sigma).*(y - (y-y_bar)/(1 +t)).*(1./b - 1./b.^2));
end
